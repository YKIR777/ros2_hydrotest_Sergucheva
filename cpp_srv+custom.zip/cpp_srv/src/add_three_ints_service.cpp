#include "rclcpp/rclcpp.hpp"
#include "custom_msg_srv/srv/add_three_ints.hpp"                                        // CHANGE
#include <cstring>
#include <memory>
#include <cctype>
using namespace std;
void add(const std::shared_ptr<custom_msg_srv::srv::AddThreeInts::Request> request,     // CHANGE
          std::shared_ptr<custom_msg_srv::srv::AddThreeInts::Response>       response)  // CHANGE
{
  response->len = 0; // Initialize the length counter
  const std::string& s = request->s;  // Using input_str for clarity

  for (char c : s) {
    if (!std::isspace(c)) {  // Check if character is not a space
        response->len++;      // Increment count for letters and symbols
    }
  }                        
  RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Incoming request\ns: [%s]",// CHANGE
                request.get()->s.c_str());                                         // CHANGE
  RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "sending back response: [%d]", (int)response->len);
}

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);

  std::shared_ptr<rclcpp::Node> node = rclcpp::Node::make_shared("add_three_ints_server");   // CHANGE

  rclcpp::Service<custom_msg_srv::srv::AddThreeInts>::SharedPtr service =               // CHANGE
    node->create_service<custom_msg_srv::srv::AddThreeInts>("add_three_ints",  &add);   // CHANGE

  RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Ready to add three ints.");                     // CHANGE

  rclcpp::spin(node);
  rclcpp::shutdown();
}
