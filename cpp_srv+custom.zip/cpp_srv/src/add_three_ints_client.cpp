#include "rclcpp/rclcpp.hpp"
#include "custom_msg_srv/srv/add_three_ints.hpp"                                       // CHANGE
#include <chrono>
#include <cstdlib>
#include <memory>
#include <string>
#include <cctype>
using namespace std::chrono_literals;

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);

  if (argc != 2) { // CHANGE
      RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "usage: add_three_ints_client Your message here");      // CHANGE
      return 1;
  }

  std::shared_ptr<rclcpp::Node> node = rclcpp::Node::make_shared("add_three_ints_client");  // CHANGE
  rclcpp::Client<custom_msg_srv::srv::AddThreeInts>::SharedPtr client =                // CHANGE
    node->create_client<custom_msg_srv::srv::AddThreeInts>("add_three_ints");          // CHANGE

  auto request = std::make_shared<custom_msg_srv::srv::AddThreeInts::Request>();       // CHANGE
  request->s = argv[1];                                                           // CHANGE

  while (!client->wait_for_service(1s)) {
    if (!rclcpp::ok()) {
      RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Interrupted while waiting for the service. Exiting.");
      return 0;
    }
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "service not available, waiting again...");
  }

  auto result = client->async_send_request(request);
  // Wait for the result.
  if (rclcpp::spin_until_future_complete(node, result) ==
    rclcpp::FutureReturnCode::SUCCESS)
  {
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Len: [%ld]", result.get()->len);
  } else {
    RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Failed to call service add_three_ints");    // CHANGE
  }

  rclcpp::shutdown();
  return 0;
}
