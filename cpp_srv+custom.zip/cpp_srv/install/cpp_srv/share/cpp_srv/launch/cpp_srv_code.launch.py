from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()
    
    server_node = Node(
    package="cpp_srv",
    executable="server",
    )
    
    client_node = Node(
    package="cpp_srv",
    executable="client",
    )
    
    ld.add_action(server_node)
    ld.add_action(client_node)
    return ld
